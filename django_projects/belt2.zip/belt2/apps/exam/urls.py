from django.conf.urls import url
from . import views           # This line is new!
urlpatterns = [
    url(r'^$', views.index), 
    url(r'^process$', views.create), 
    url(r'^process2$', views.login), 
    url(r'^appointments$', views.success), 
    url(r'^appointments/add$', views.add), 
  	url(r'^appointments/(?P<id>\d+)$', views.update),
  	url(r'^appointments/(?P<id>\d+)/process3$', views.process3),  	
  	url(r'^appointments/(?P<id>\d+)/delete$', views.destroy),  	
  ]