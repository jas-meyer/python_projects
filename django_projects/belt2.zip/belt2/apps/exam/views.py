from django.shortcuts import render, redirect
import bcrypt
from models import *
from django.contrib import messages
import datetime
now = datetime.datetime.now()
def index(request):

	return render(request,"exam/index.html")
def create(request):
	if request.POST['password'] != request.POST['confirm']:
		print "The confirmation password must match the password"
		return redirect('/')
	email = str(request.POST['email'])
	a = User.objects.filter(email = email)
	errors = User.objects.basic_validator(request.POST , a)
	if len(errors):
		for tag, error in errors.iteritems():
			messages.error(request, error, extra_tags = tag)
			print messages.error
		return redirect('/')
	password = str(request.POST['password'])
	hash1 = bcrypt.hashpw(password .encode(), bcrypt.gensalt())
	firstname = str(request.POST['firstname'])
	lastname = str(request.POST['lastname'])
	email = str(request.POST['email'])
	print request.POST['dob']
	dob = request.POST['dob']
	User.objects.create(first_name = firstname, last_name = lastname, email = email, dob= dob, password = hash1) 
	b = User.objects.filter(email = email)
	request.session['firstname'] = firstname
	request.session['id'] = b[0].id
	return redirect('/appointments')
def login(request):
	email = str(request.POST['logemail'])
	a = User.objects.filter(email = email)
	errors = User.objects.password_check(request.POST, a)
	if len(errors):
		for tag, error in errors.iteritems():
			messages.error(request, error, extra_tags = tag)
			print errors
		return redirect('/')
	
	else:
		request.session['firstname']=a[0].first_name
		request.session['id'] = a[0].id
		print request.session['firstname']
		return redirect('/appointments')
		
def success(request):
	today = now.strftime("%Y-%m-%d")
	request.session['today'] = today
	return render(request,"exam/success.html", {"appoint" : Appoint.objects.filter(user_id = request.session['id'])})
def add(request):
	task = str(request.POST['tasks'])
	dt = request.POST['dt']
	time = request.POST['tm']
	status = "Pending"
	Appoint.objects.create(task = task , time = time  , status = status  , date = dt, user_id = request.session['id'])

	return redirect('/appointments')
def process3(request, id):
	appoint = Appoint.objects.get(id = id)
	appoint.task = request.POST['tasks']
	appoint.status = request.POST['status']
	appoint.date = request.POST['dt']
	appoint.time = request.POST['tm']
	appoint.save()
	return redirect('/appointments')
def update(request, id):

	return render(request, "exam/update.html", {"appoint" : Appoint.objects.get(id = id)})
def destroy(request, id):
	b = Appoint.objects.get(id = id)
	b.delete()
	return redirect('/appointments')
# Create your views here.
