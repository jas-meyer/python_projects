from django.conf.urls import url
from . import views           # This line is new!
urlpatterns = [
    url(r'^main$', views.index), 
    url(r'^quotes$', views.success), 
    url(r'^process$', views.create), 
    url(r'^process2$', views.login),	
    url(r'^process3$', views.process3),
    url(r'^process4/(?P<id>\d+)$', views.process4),	
    url(r'^users/(?P<id>\d+)$', views.user),	
    url(r'^remove/(?P<id>\d+)$', views.remove),	
    url(r'^logout$', views.logout),
  ]