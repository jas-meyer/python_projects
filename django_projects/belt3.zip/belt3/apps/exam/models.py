from __future__ import unicode_literals

from django.db import models
import re
import bcrypt
import datetime 

class UserManager(models.Manager):
	def basic_validator(self, postData, data):
		errors = {}
		if len(data) > 1:
			errors['email'] = " Email is already in the database!"   
		else:
			if len(postData['name']) < 3:
				errors["name"] = "The name should be at least 3 characters"
			if len(postData['alias']) < 3:
				errors["alias"] = "The username should be at least 3 characters"
			if len(postData['password']) < 8:
				errors["password"] = "The password need to be at least 8 characters"
			now = datetime.datetime.today().strftime('%Y-%m-%d')
			if postData['dob'] >= now:
				errors['dob2'] = "The date of birth must be in the past"
			if len(postData['dob']) < 1:
				errors['dob'] = "Please enter your date of birth"
			if postData['password'] != postData['confirm']:
				error['confirm'] = "Please enter the same password in password and confirm password fields"
		return errors
	def password_check(self, postData, data):
		errors = {}
		if len(postData['logemail']) < 1:
			errors["email"] = "The email should not be blank"
		elif len(data) < 1:
			errors['email'] = "The email is not in database!"
		elif len(postData['logpassword']) < 1:
			errors['logpassword'] = "The password field cannot be blank"
		else:
			logpass = str(postData['logpassword'])
			storedpass = data[0].password
			if not bcrypt.checkpw(logpass .encode(), storedpass .encode()):
				errors['password'] = "Password does not match"
		return errors
class QuoteManager(models.Manager):
	def quote_check(self, postData):
		errors = {}
		if len(postData['quoted_by']) < 4:
			errors['quoted_by'] = "Quoted by field should have more than 3 characters"
		if len(postData['message']) < 11:
			errors['message'] = "Message field should have more than 10 characters"
		return errors

class User(models.Model):
	name = models.CharField(max_length=255)
	alias = models.CharField(max_length=255)
	email = models.CharField(max_length=255)
	password = models.CharField(max_length = 255)
	dob = models.DateField()
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)
	objects = UserManager()

class Quote(models.Model):
	message = models.TextField()
	quoted_by = models.CharField(max_length=255)
	users = models.ForeignKey(User, related_name="posted_by")
	objects = QuoteManager()
class Favorite(models.Model):
	quotes = models.ForeignKey(Quote, related_name="favorites")
	users = models.ForeignKey(User, related_name = "favorites2")


# Create your models here.
