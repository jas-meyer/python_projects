from django.shortcuts import render, redirect
import bcrypt
from models import *
from django.contrib import messages
def index(request):

	return render(request,"exam/index.html")
def create(request):
	email = request.POST['email']
	a = User.objects.filter(email = email)
	errors = User.objects.basic_validator(request.POST , a)
	if len(errors):
		for tag, error in errors.iteritems():
			messages.error(request, error, extra_tags = tag)
			print messages.error
		return redirect('/main')
	password = str(request.POST['password'])
	hash1 = bcrypt.hashpw(password .encode(), bcrypt.gensalt())
	name = request.POST['name']
	alias = request.POST['alias']
	dob = request.POST['dob']
	print dob
	User.objects.create(name = name, alias = alias , email = email, password = hash1, dob= dob) 
	request.session['alias'] = alias
	b = User.objects.last()
	request.session['id'] = b.id
	return redirect('/quotes')
def login(request):
	email = str(request.POST['logemail'])
	a = User.objects.filter(email = email)
	errors = User.objects.password_check(request.POST, a)
	if len(errors):
		for tag, error in errors.iteritems():
			messages.error(request, error, extra_tags = tag)
			print errors
		return redirect('/main')
	
	else:
		request.session['alias']=a[0].alias
		request.session['id'] = a[0].id
		return redirect('/quotes')
		
def success(request):
	a  = Favorite.objects.all()
	favs = Favorite.objects.filter(users_id = request.session['id']).values_list('quotes__id')
	quotes = Quote.objects.all().exclude(id__in=favs)
	if len(a) > 0:
		favorites = Favorite.objects.filter(users_id = request.session['id']) 
		for b in favorites:
			c = b.quotes_id
			print c 
	
	else: 
		favorites = {}

	context = {
		'quotes': Quote.objects.all(),
		'users' : User.objects.all(),
		'favorites' : favorites,
		'my_quotes' : quotes,

	}

	return render(request,"exam/success.html", context,)
def process3(request):

	
	errors = Quote.objects.quote_check(request.POST)
	if len(errors):
		for tag, error in errors.iteritems():
			messages.error(request, error, extra_tags = tag)
			print errors
		return redirect('/quotes')
	message = request.POST['message']
	quoted_by = request.POST['quoted_by']

	Quote.objects.create(message = message, quoted_by = quoted_by, users_id= request.session['id'])

	return redirect('/quotes')
def process4(request,id):

	a = Quote.objects.get(id = id)
	quoteid = a.id

	Favorite.objects.create(quotes_id = quoteid, users_id = request.session['id'])


	return redirect('/quotes')
def user(request, id):
	quotes = Quote.objects.all()
	count = 0 
	intid = int(id)
	quote = []
	for quote in quotes:
		if intid == quote.users_id:
			count +=1
	b = Quote.objects.filter(users_id = id)


	context = {
		'user' : User.objects.get(id = id),
		'count' : count,
		'quotes' : b
	}

	return render(request,"exam/user.html", context)
def remove(request, id):
	b = Favorite.objects.get(id = id)
	b.delete()
	return redirect('/quotes')
def logout(request):
	del request.session['id']
	del request.session['alias']
	return redirect('/main')
# Create your views here.
