from django.shortcuts import render, redirect
import bcrypt
from models import User

def index(request):

	return render(request,"register/index.html")
def create(request):
	if request.POST['password'] != request.POST['confirm']:
		print "The confirmation password must match the password"
		return redirect('/')
	password = str(request.POST['password'])
	hash1 = bcrypt.hashpw(password .encode(), bcrypt.gensalt())
	errors = User.objects.basic_validator(request.POST)
	if len(errors):
		for tag, error in errors.iteritems():
			messages.error(request, error, extra_tags = tag)
		return redirect('/users/new')
	firstname = str(request.POST['firstname'])
	lastname = str(request.POST['lastname'])
	email = str(request.POST['email'])
	User.objects.create(first_name = firstname, last_name = lastname, email = email, password = hash1) 
	request.session['firstname'] = firstname
	return redirect('/success')
def login(request):
	email = str(request.POST['logemail'])
	a = User.objects.filter(email = email)
	print a
	print a[0].first_name
	logpass = str(request.POST['logpassword'])
	storedpass = a[0].password
	if bcrypt.checkpw(logpass .encode(), storedpass .encode()):
		request.session['firstname']=a[0].first_name
		print request.session['firstname']
		return redirect('/success')
	else:
		return redirect('/')
def success(request):

	return render(request,"register/success.html")

# Create your views here.
