from django.conf.urls import url
from . import views           # This line is new!
urlpatterns = [
    url(r'^main$', views.index), 
    url(r'^process$', views.create), 
    url(r'^process2$', views.login), 
    url(r'^travels$', views.success), 
    url(r'^travel/add$', views.add),
    url(r'^process3/(?P<id>\d+)$', views.addition), 
    url(r'^logout$', views.logout),
    url(r'^travels/destination/(?P<id>\d+)$', views.destination), 
  	url(r'^join/(?P<id>\d+)$', views.join), 						
  ]