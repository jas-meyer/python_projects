from django.shortcuts import render, redirect
import bcrypt
import datetime
from models import *
from django.contrib import messages
def index(request):

	return render(request,"exam/index.html")
def create(request):
	if request.POST['password'] != request.POST['confirm']:
		print "The confirmation password must match the password"
		return redirect('/main')
	username = str(request.POST['username'])
	a = User.objects.filter(username = username)
	errors = User.objects.basic_validator(request.POST , a)
	if len(errors):
		for tag, error in errors.iteritems():
			messages.error(request, error, extra_tags = tag)
			print messages.error
		return redirect('/main')
	password = str(request.POST['password'])
	hash1 = bcrypt.hashpw(password .encode(), bcrypt.gensalt())
	name = str(request.POST['name'])
	username = str(request.POST['username'])
	User.objects.create(name = name, username = username, password = hash1) 
	a = User.objects.filter(username = username)
	request.session['name'] = a[0].name
	request.session['id'] = a[0].id
	return redirect('/travels')
def login(request):
	username = str(request.POST['logusername'])
	a = User.objects.filter(username = username)
	errors = User.objects.password_check(request.POST, a)
	if len(errors):
		for tag, error in errors.iteritems():
			messages.error(request, error, extra_tags = tag)
			print errors
		return redirect('/main')
	
	else:
		request.session['name']=a[0].name
		request.session['id'] = a[0].id
		print request.session['name']
		return redirect('/travels')
		
def success(request):
	this_user=User.objects.get(id = request.session['id'])
	this_user.trips.all()
	return render(request,"exam/success.html", {'mytrips': Trip.objects.filter(created_by=request.session['id'])|User.objects.get(id = request.session['id']).trips.all(), 'trips': Trip.objects.exclude(created_by=request.session['id'])})
def add(request):
	now = datetime.datetime.today().strftime('%Y-%m-%d')
	print now

	
	return render(request, "exam/add.html")

def addition(request, id):

	errors = Trip.objects.trip_validator(request.POST)
	if len(errors):
		for tag, error in errors.iteritems():
			messages.error(request, error, extra_tags = tag)
			print messages.error
		return redirect('/travel/add')
	this_user = User.objects.get(id = id)
	Trip.objects.create(created_by= this_user, destination = request.POST['destination'], description = request.POST['description'], travelstart = request.POST['travelstart'], travelend = request.POST['travelend']) 
	
	return redirect('/travels')
def destination(request, id):

	return render(request, "exam/destination.html", {'trip': Trip.objects.get(id = id)})
def join(request, id):
	this_user = User.objects.get(id = request.session['id'])
	this_trip = Trip.objects.get(id = id)
	this_trip.users.add(this_user)
	return redirect('/travels')
def logout(request):
	del request.session['id']
	del request.session['name']
	return redirect('/main')
# Create your views here.
