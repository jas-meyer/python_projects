from __future__ import unicode_literals

from django.db import models
import re
import bcrypt
import datetime 

class UserManager(models.Manager):
	def basic_validator(self, postData, data):
		errors = {}
		if len(data) > 1:
			errors['username'] = "Username is already in the database!"   
		else:
			if len(postData['name']) < 3:
				errors["name"] = "The name should be at least 3 characters"
			if len(postData['username']) < 3:
				errors["username"] = "The username should be at least 3 characters"
			if len(postData['password']) < 8:
				errors["password"] = "The password need to be at least 8 characters"
		return errors
	def password_check(self, postData, data):
		errors = {}
		if len(postData['logusername']) < 1:
			errors["username"] = "The username should not be blank"
		elif len(data) < 1:
			errors['username'] = "The username is not in database!"
		else:
			logpass = str(postData['logpassword'])
			storedpass = data[0].password
			if not bcrypt.checkpw(logpass .encode(), storedpass .encode()):
				errors['password'] = "Password does not match"
		return errors
class TripManager(models.Manager):
	def trip_validator(self, postData):
		errors={}
		if len(postData['destination']) < 1:
			errors['destination'] = "Destination field cannot be blank!"
		if len(postData['description']) < 1:
			errors['description'] = "Description field cannot be blank!"
		if len(postData['travelstart']) < 1:
			errors['travelstart'] = "Date From field cannot be blank!"
		if len(postData['travelend']) < 1:
			errors['travelend'] = "Date To field cannot be blank!"
		if postData['travelstart'] > postData['travelend']:
			errors['traveldate'] = "Date To date must come after Date From date"
		now = datetime.datetime.today().strftime('%Y-%m-%d')
		if postData['travelstart'] < now:
			 errors['travel'] = "Travel date must be in future"
		if postData['travelend'] < now: 
			errors['travel'] = "Travel date must be in future"
		return errors

class User(models.Model):
	name = models.CharField(max_length=255)
	username = models.CharField(max_length=255)
	password = models.CharField(max_length = 255)
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)
	objects = UserManager()

class Trip(models.Model):
	destination = models.CharField(max_length=255)
	description = models.CharField(max_length=255)
	travelstart = models.DateField()
	travelend = models.DateField()
	users = models.ManyToManyField(User, related_name ="trips")
	created_by = models.ForeignKey(User, related_name= "creator")
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)
	objects = TripManager()


# Create your models here.
