from flask import Flask, render_template, request, redirect  # Import Flask to allow us to create our app.
app = Flask(__name__)   

@app.route('/')
def login():
	return render_template('index.html')

@app.route('/process', methods =['POST'])
def process():
	name = request.form['name']
	location = request.form['location']
	language = request.form['language']
	textbox = request.form['textbox']

	print "Name:",name
	print "Location:",location
	print "Language:",language
	print "Comments:",textbox
	return render_template('process.html', n = name, loc=location, lan = language, text= textbox)



app.run(debug=True) 